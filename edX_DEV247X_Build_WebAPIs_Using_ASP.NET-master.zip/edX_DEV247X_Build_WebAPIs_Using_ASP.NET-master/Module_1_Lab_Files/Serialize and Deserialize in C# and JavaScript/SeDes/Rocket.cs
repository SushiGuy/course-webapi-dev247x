namespace SeDes {
    public class Rocket {
        public int ID { get; set; }
        public string Builder { get; set; }
        public string Target { get; set; }
        public double Speed { get; set; }
    }
}