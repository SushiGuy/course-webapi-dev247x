namespace SeDes {
    public class UFO {
        public string Target { get; set; }
        public double Speed { get; set; }
    }
}