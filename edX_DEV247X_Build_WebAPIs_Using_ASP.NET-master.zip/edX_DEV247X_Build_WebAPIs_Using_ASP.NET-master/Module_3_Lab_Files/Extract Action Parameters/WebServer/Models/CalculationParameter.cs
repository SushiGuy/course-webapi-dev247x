namespace WebServer.Models {
    public class CalculationParameter {
        public double A { get; set; }
        public double B { get; set; }
    }
}